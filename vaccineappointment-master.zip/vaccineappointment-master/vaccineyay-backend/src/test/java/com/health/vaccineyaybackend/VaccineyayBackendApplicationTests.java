package com.health.vaccineyaybackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaccineyayBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
