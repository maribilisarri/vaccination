package com.health.vaccineyaybackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VaccineyayBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(VaccineyayBackendApplication.class, args);
	}

}
